#include <GLFW/glfw3.h>
#include "linmath.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <vector>
#include <time.h>
#include <cmath>

#define PI 3.14159265f

using namespace std;

const float DEG2RAD = 3.14159 / 180;

void processInput(GLFWwindow* window);

enum BRICKTYPE { REFLECTIVE, DESTRUCTABLE };
enum ONOFF { ON, OFF };

class Brick {
public:
    float red, green, blue;
    float x, y, width;
    BRICKTYPE brick_type;
    ONOFF onoff;
    int hits;  // Track the number of hits on the brick
    int totalHits;  // Track the total number of hits on the brick

    Brick(BRICKTYPE bt, float xx, float yy, float ww, float rr, float gg, float bb) {
        brick_type = bt; x = xx; y = yy, width = ww; red = rr, green = gg, blue = bb;
        onoff = ON;
        hits = 0;  // Initialize hits to 0
        totalHits = 0;  // Initialize total hits to 0
    };

    void drawBrick() {
        if (onoff == ON) {
            double halfside = width / 2;

            glColor3d(red, green, blue);
            glBegin(GL_POLYGON);

            glVertex2d(x + halfside, y + halfside);
            glVertex2d(x + halfside, y - halfside);
            glVertex2d(x - halfside, y - halfside);
            glVertex2d(x - halfside, y + halfside);

            glEnd();
        }
    }

    void incrementHits() {
        hits++;
        totalHits++;
    }

    void resetHits() {
        hits = 0;
    }
};

class Circle {
public:
    float red, green, blue;
    float radius;
    float x;
    float y;
    float velocityX, velocityY; // Velocity components

    Circle(double xx, double yy, double rr, float r, float g, float b) {
        x = xx;
        y = yy;
        radius = rr;
        red = r;
        green = g;
        blue = b;

        // Initialize velocity
        float speed = 0.015f;
        float angle = static_cast<float>(rand()) / static_cast<float>(RAND_MAX) * 2.0f * PI; // Random angle
        velocityX = speed * cos(angle);
        velocityY = speed * sin(angle);
    }

    void CheckCircleCollision(Circle& other) {
        float dx = other.x - x;
        float dy = other.y - y;
        float distance = sqrt(dx * dx + dy * dy);
        float minDistance = radius + other.radius;

        if (distance < minDistance) { // Collision detected
            // Calculate the normal vector
            float nx = dx / distance;
            float ny = dy / distance;

            // Calculate the overlap
            float overlap = minDistance - distance;

            // Move the circles apart based on the overlap
            x -= nx * overlap / 2;
            other.x += nx * overlap / 2;
            y -= ny * overlap / 2;
            other.y += ny * overlap / 2;

            // Reflect the velocities
            float tempVX = velocityX;
            float tempVY = velocityY;

            velocityX = other.velocityX;
            velocityY = other.velocityY;

            other.velocityX = tempVX;
            other.velocityY = tempVY;
        }
    }

    void CheckCollision(Brick* brk, Brick& centerBrick) {
        if (brk->onoff == OFF)
            return;

        float halfWidth = brk->width / 2;

        if (x + radius > brk->x - halfWidth && x - radius < brk->x + halfWidth &&
            y + radius > brk->y - halfWidth && y - radius < brk->y + halfWidth) {
            if (brk->brick_type == DESTRUCTABLE) {
                radius += 0.01;
                brk->onoff = OFF;
            }
            else if (brk->brick_type == REFLECTIVE) {
                // Reflect and reposition ball after collision
                if (x + radius > brk->x - halfWidth && x - radius < brk->x + halfWidth) {
                    if (y + radius > brk->y + halfWidth || y - radius < brk->y - halfWidth) {
                        velocityY = -velocityY; // Reverse Y velocity
                    }
                }
                if (y + radius > brk->y - halfWidth && y - radius < brk->y + halfWidth) {
                    if (x + radius > brk->x + halfWidth || x - radius < brk->x - halfWidth) {
                        velocityX = -velocityX; // Reverse X velocity
                    }
                }
            }

            // Increment hits only for the center brick
            if (brk == &centerBrick) {
                centerBrick.incrementHits(); // Increment the hit count for the center square
            }
        }
    }

    void MoveOneStep() {
        x += velocityX;
        y += velocityY;

        // Check for wall collisions
        if (x + radius > 1.0 || x - radius < -1.0) {
            velocityX = -velocityX; // Reverse X velocity
            x = (x + radius > 1.0) ? 1.0 - radius : -1.0 + radius; // Adjust position
        }
        if (y + radius > 1.0 || y - radius < -1.0) {
            velocityY = -velocityY; // Reverse Y velocity
            y = (y + radius > 1.0) ? 1.0 - radius : -1.0 + radius; // Adjust position
        }
    }

    void DrawCircle() {
        glColor3f(red, green, blue);
        glBegin(GL_TRIANGLE_FAN);
        glVertex2f(x, y); // Center of the circle
        int numSegments = 100;
        for (int i = 0; i <= numSegments; i++) {
            float angle = i * 2.0f * PI / numSegments; // Calculate angle
            glVertex2f(x + cos(angle) * radius, y + sin(angle) * radius);
        }
        glEnd();
    }
};

vector<Circle> world;

int main(void) {
    srand(time(NULL));

    if (!glfwInit()) {
        exit(EXIT_FAILURE);
    }
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);
    GLFWwindow* window = glfwCreateWindow(480, 480, "8-2 Assignment           By: Darrell Walker", NULL, NULL);
    if (!window) {
        glfwTerminate();
        exit(EXIT_FAILURE);
    }
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    std::cout << " Hello, this is a simple animation of balls bouncing around in a 2D scene,\n Everytime the center square is hit 10 times by a ball, it will spawn a new ball and change colors.\n the balls do in fact bounce off of one another\n once the ball count reaches 500+ close the program to prevent crash.\n \n Hit the 'Space Bar' to Start.\n\n Sorry for the bugs!\n\n" << std::endl;

    Brick brick(REFLECTIVE, 0.0, 1.9, 2.0, 1, 0, 0);  // top wall
    Brick brick2(REFLECTIVE, 0.0, -1.9, 2.0, 1, 0, 0); // bottom wall
    Brick brick3(REFLECTIVE, 1.9, 0.0, 2.0, 1, 0, 0);   // right wall
    Brick brick4(REFLECTIVE, -1.9, 0.0, 2.0, 1, 0, 0);  // left wall
    Brick brick5(REFLECTIVE, 0.0, 0.0, 0.3, 0, 1, 0);   // center square

    while (!glfwWindowShouldClose(window)) {
        // Setup View
        float ratio;
        int width, height;
        glfwGetFramebufferSize(window, &width, &height);
        ratio = width / (float)height;
        glViewport(0, 0, width, height);
        glClear(GL_COLOR_BUFFER_BIT);

        processInput(window);

        for (int i = 0; i < world.size(); i++) {
            for (int j = i + 1; j < world.size(); j++) {
                world[i].CheckCircleCollision(world[j]); // Check for collisions between circles
            }

            world[i].CheckCollision(&brick, brick5);
            world[i].CheckCollision(&brick2, brick5);
            world[i].CheckCollision(&brick3, brick5);
            world[i].CheckCollision(&brick4, brick5);
            world[i].CheckCollision(&brick5, brick5);
            world[i].MoveOneStep();
            world[i].DrawCircle();
        }

        // Draw all bricks
        brick.drawBrick();
        brick2.drawBrick();
        brick3.drawBrick();
        brick4.drawBrick();
        brick5.drawBrick();  // Draw the center square

        std::cout << "\rCurrent hits on center square: " << brick5.hits
            << "     |       Total hits on center square: " << brick5.totalHits
            << "     |       Current ball count: " << world.size() << std::flush;

        if (brick5.hits >= 10) {
            // Spawn a new ball and reset center brick's hit count
            double r = rand() / (double)RAND_MAX;
            double g = rand() / (double)RAND_MAX;
            double b = rand() / (double)RAND_MAX;

            // Set the initial position of the new ball to avoid overlap with the center square and existing balls
            float newX, newY;
            bool validPosition = false;

            while (!validPosition) {
                newX = (rand() % 2 == 0) ? (rand() / (float)RAND_MAX) * 0.5 - 0.8 : (rand() / (float)RAND_MAX) * 0.5 - 0.8; // Random X position
                newY = (rand() % 2 == 0) ? (rand() / (float)RAND_MAX) * 0.5 - 0.8 : (rand() / (float)RAND_MAX) * 0.5 - 0.8; // Random Y position

                // Ensure the new ball is not overlapping with the center square
                if (!(newX >= -0.15 && newX <= 0.15 && newY >= -0.15 && newY <= 0.15)) {
                    // Check against existing balls
                    validPosition = true;
                    for (const Circle& ball : world) {
                        float dx = newX - ball.x;
                        float dy = newY - ball.y;
                        float distance = sqrt(dx * dx + dy * dy);
                        if (distance < (0.03 + ball.radius)) { // Check for overlap
                            validPosition = false;
                            break;
                        }
                    }
                }
            }

            Circle newBall(newX, newY, 0.03, r, g, b);  // Create a ball at a random position
            world.push_back(newBall);  // Add the ball to the world

            // Change the center square's color randomly
            brick5.red = rand() / (double)RAND_MAX;
            brick5.green = rand() / (double)RAND_MAX;
            brick5.blue = rand() / (double)RAND_MAX;

            // Reset the hit counter
            brick5.resetHits();
        }

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwDestroyWindow(window);
    glfwTerminate();
    exit(EXIT_SUCCESS);
}

bool spacebarPressed = false; // Flag to track if the spacebar was pressed

void processInput(GLFWwindow* window) {
    if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS && !spacebarPressed) {
        double r, g, b;
        r = rand() / (double)RAND_MAX;  // Random color
        g = rand() / (double)RAND_MAX;
        b = rand() / (double)RAND_MAX;

        // Set the initial position of the new ball to avoid overlap with the center square and existing balls
        float newX, newY;
        bool validPosition = false;

        while (!validPosition) {
            newX = (rand() % 2 == 0) ? (rand() / (float)RAND_MAX) * 0.5 - 0.8 : (rand() / (float)RAND_MAX) * 0.5 - 0.8; // Random X position
            newY = (rand() % 2 == 0) ? (rand() / (float)RAND_MAX) * 0.5 - 0.8 : (rand() / (float)RAND_MAX) * 0.5 - 0.8; // Random Y position

            // Ensure the new ball is not overlapping with the center square
            if (!(newX >= -0.3 && newX <= 0.3 && newY >= -0.3 && newY <= 0.3)) {
                // Check against existing balls
                validPosition = true;
                for (const Circle& ball : world) {
                    float dx = newX - ball.x;
                    float dy = newY - ball.y;
                    float distance = sqrt(dx * dx + dy * dy);
                    if (distance < (0.06 + ball.radius)) { // Check for overlap
                        validPosition = false;
                        break;
                    }
                }
            }
        }

        Circle newBall(newX, newY, 0.06, r, g, b);  // Create a ball at a random position
        world.push_back(newBall);  // Add the ball to the world

        spacebarPressed = true; // Set flag to true to prevent multiple spawns in one frame
    }
}